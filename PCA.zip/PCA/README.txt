# votingVision
These are the codes for the PCA classifier. 
The try class is a complete demo of the classification process with detailed explaination in the comments. 
To run the project, you should run the try class (The image.zip should be unzipped before running the project).
Parameters at line 19-24 of the try class can be modified for other tests or other classification tasks.
To perform other classification tasks, line 66 should also be modified to initialze the classifier with different parameters.

